// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

define([], function() {
    'use strict';

    /**
     * Add the handler for the small core Bulk actions toolbar patch.
     *
     * @param {number} courseid Course ID.
     * @param {string} endpoint Plugin endpoint.
     */
    const init = (courseid, endpoint) => {
        document.addEventListener('click', event => {
            const button = event.target.closest('[data-action="assignBulkClose"]');
            if (!button) {
                return;
            }

            event.preventDefault();
            event.stopImmediatePropagation();

            const checkboxes = Array.from(document.querySelectorAll('[data-bulkcheckbox]:checked'))
                .filter(checkbox => checkbox.closest('li.activity'));
            const form = document.createElement('form');
            form.method = 'post';
            form.action = endpoint;

            const addHidden = (name, value) => {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = name;
                input.value = value;
                form.appendChild(input);
            };

            addHidden('courseid', courseid);
            addHidden('sesskey', M.cfg.sesskey);
            checkboxes.forEach(checkbox => {
                if (checkbox.dataset.id) {
                    addHidden('cmids[]', checkbox.dataset.id);
                }
            });

            document.body.appendChild(form);
            form.submit();
        }, true);
    };

    return {init: init};
});
