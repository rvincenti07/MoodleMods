<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Bulk set quiz opening and closing times';
$string['setcloseddate'] = 'Open / Closed Date';
$string['pageheading'] = 'Open / Closed Date';
$string['selectquizzesfirst'] = 'Select one or more quizzes in Bulk actions before choosing Open / Closed Date.';
$string['selectonlyquizzes'] = 'Open / Closed Date only works when the selected activities are all quizzes.';
$string['samesectionrequired'] = 'Select quizzes from one section only, then choose Open / Closed Date again.';
$string['selectedquizzes'] = 'Selected quizzes ({$a}):';
$string['sectionlabel'] = 'Section: {$a}';
$string['timeopen'] = 'New quiz opening date and time';
$string['timeopen_help'] = 'This changes Moodle’s “Open the quiz” date and time for every selected quiz.';
$string['timeclose'] = 'New quiz closing date and time';
$string['timeclose_help'] = 'This changes Moodle’s “Close the quiz” date and time for every selected quiz.';
$string['applydates'] = 'Update selected quizzes';
$string['updated'] = 'Updated the opening and closing times for {$a} quiz activity/activities.';
$string['dateconflicts'] = 'The opening date and time must be earlier than the closing date and time.';
$string['overridewarning'] = 'Individual student or group quiz overrides remain unchanged and can give some students different opening or closing times.';
