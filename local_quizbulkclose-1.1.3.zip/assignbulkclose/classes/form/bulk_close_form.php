<?php
// This file is part of Moodle - http://moodle.org/

namespace local_assignbulkclose\form;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');

/** Form for applying one opening and closing time to selected quizzes in one section. */
class bulk_close_form extends \moodleform {

    /** Define the form. */
    protected function definition(): void {
        $mform = $this->_form;
        $courseid = (int)$this->_customdata['courseid'];
        $quizhtml = $this->_customdata['quizhtml'];

        $mform->addElement('hidden', 'courseid', $courseid);
        $mform->setType('courseid', PARAM_INT);
        $mform->addElement('html', $quizhtml);

        // Match Moodle's quiz timing controls: each date can be enabled or
        // disabled independently. Use future defaults so both controls start
        // enabled, while leaving the teacher free to change either one.
        $mform->addElement('date_time_selector', 'timeopen',
            get_string('timeopen', 'local_assignbulkclose'), ['optional' => true]);
        $mform->setDefault('timeopen', time());
        $mform->addHelpButton('timeopen', 'timeopen', 'local_assignbulkclose');

        $mform->addElement('date_time_selector', 'timeclose',
            get_string('timeclose', 'local_assignbulkclose'), ['optional' => true]);
        $mform->setDefault('timeclose', time() + DAYSECS);
        $mform->addHelpButton('timeclose', 'timeclose', 'local_assignbulkclose');

        $mform->addElement('hidden', 'sesskey', sesskey());
        $mform->setType('sesskey', PARAM_RAW);
        $this->add_action_buttons(false, get_string('applydates', 'local_assignbulkclose'));
    }
}
