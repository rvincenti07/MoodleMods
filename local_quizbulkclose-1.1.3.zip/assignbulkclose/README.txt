Bulk set quiz opening and closing times (local_assignbulkclose)
=================================================

Purpose
-------
Adds “Open / Closed Date” to Moodle 5.2's course-page Bulk actions toolbar. The
teacher selects quiz activities using Moodle's existing activity checklist,
then chooses one opening date and time and one closing date and time for all
selected quizzes. Each date has its own Enable checkbox, so either restriction
can also be removed. The selected quizzes must all be in the same course section.

This updates each quiz's opening time (timeopen) and closing time (timeclose).
When both dates are enabled, the opening time must be earlier than the closing
time. Quiz due dates are unchanged.
Existing individual student or group overrides are not changed and may continue
to give some students different effective opening or closing times.

Moodle 5.2 does not provide a local-plugin callback for adding a custom course
Bulk actions toolbar item. This package therefore includes one small core patch
in core-bulk-actions.patch in addition to the local plugin.

Install or upgrade
------------------
1. Install the ZIP through Site administration > Plugins > Install plugins.
   The ZIP contains the local_assignbulkclose plugin folder at its root.
   If you already installed an earlier version, upload this ZIP as the plugin
   upgrade; Moodle will update the existing plugin.
2. If you have not already applied the Bulk actions patch, back up the Moodle
   code directory, then from the Moodle code root apply:
   patch -p1 < /path/to/core-bulk-actions.patch
   If you already applied the patch from version 1.0.1, do not apply it again.
3. Purge Moodle caches from Site administration > Development > Purge caches.
   If your production server does not rebuild Moodle AMD modules automatically,
   run Moodle's standard grunt amd build step.
4. Open a course in edit mode, click Bulk actions, select only quizzes from one
   section, and click Open / Closed Date.
5. Enable the opening and/or closing date/time, choose the dates, then click
   Update selected quizzes. Unchecking a date removes that restriction. After
   a successful update, Moodle returns to that section with a success notice.

The tool stops without changing any quiz if both dates are enabled and the
opening time is not earlier than the closing time. Quiz overrides remain
unchanged.

Requirements
------------
Moodle 5.2 or later in the 5.2 release line. Users need the standard
moodle/course:manageactivities capability in the course.
