<?php
// This file is part of Moodle - http://moodle.org/

require('../../config.php');

use local_assignbulkclose\form\bulk_close_form;

$courseid = required_param('courseid', PARAM_INT);
$course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
require_login($course);
$context = context_course::instance($courseid);
require_capability('moodle/course:manageactivities', $context);

$PAGE->set_url(new moodle_url('/local/assignbulkclose/index.php', ['courseid' => $courseid]));
$PAGE->set_context($context);
$PAGE->set_pagelayout('incourse');
$PAGE->set_title(get_string('pageheading', 'local_assignbulkclose'));
$PAGE->set_heading(format_string($course->fullname));

// The initial POST comes from the course Bulk actions toolbar. Later POSTs come
// from the date form. In both cases, only IDs from the current course are used.
$cmids = optional_param_array('cmids', [], PARAM_INT);
$cmids = array_values(array_unique(array_filter($cmids)));
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_sesskey();
}

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('pageheading', 'local_assignbulkclose'));

if (!$cmids) {
    echo $OUTPUT->notification(get_string('selectquizzesfirst', 'local_assignbulkclose'), 'error');
    echo $OUTPUT->footer();
    exit;
}

$modinfo = get_fast_modinfo($course);
$selected = [];
$sectionids = [];
$invalid = false;
foreach ($cmids as $cmid) {
    try {
        $cm = $modinfo->get_cm($cmid);
    } catch (\moodle_exception $e) {
        $invalid = true;
        break;
    }
    if ($cm->modname !== 'quiz') {
        $invalid = true;
        break;
    }
    $quiz = $DB->get_record('quiz', ['id' => $cm->instance, 'course' => $courseid], '*', IGNORE_MISSING);
    if (!$quiz) {
        $invalid = true;
        break;
    }
    $selected[$cmid] = ['cm' => $cm, 'quiz' => $quiz];
    $sectionids[$cm->section] = true;
}

if ($invalid) {
    echo $OUTPUT->notification(get_string('selectonlyquizzes', 'local_assignbulkclose'), 'error');
    echo $OUTPUT->footer();
    exit;
}
if (count($sectionids) !== 1) {
    echo $OUTPUT->notification(get_string('samesectionrequired', 'local_assignbulkclose'), 'error');
    echo $OUTPUT->footer();
    exit;
}

$sectionrecord = $DB->get_record('course_sections', ['id' => (int)array_key_first($sectionids)], '*', IGNORE_MISSING);
$sectionname = $sectionrecord ? format_string(get_section_name($course, $sectionrecord)) : '';
$summary = html_writer::tag('p', get_string('selectedquizzes', 'local_assignbulkclose', count($selected)));
$summary .= html_writer::tag('p', get_string('sectionlabel', 'local_assignbulkclose', $sectionname));
$summary .= html_writer::start_tag('ul');
$hiddenids = '';
foreach ($selected as $cmid => $item) {
    $quiz = $item['quiz'];
    $summary .= html_writer::tag('li', html_writer::link($item['cm']->url, format_string($quiz->name)));
    $hiddenids .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'cmids[]', 'value' => $cmid]);
}
$summary .= html_writer::end_tag('ul') . $hiddenids;
$summary .= $OUTPUT->notification(get_string('overridewarning', 'local_assignbulkclose'), 'warning');

$mform = new bulk_close_form(null, [
    'courseid' => $courseid,
    'quizhtml' => $summary,
]);

if ($data = $mform->get_data()) {
    $timeopen = (int)$data->timeopen;
    $timeclose = (int)$data->timeclose;
    if ($timeopen && $timeclose && $timeopen >= $timeclose) {
        echo $OUTPUT->notification(get_string('dateconflicts', 'local_assignbulkclose'), 'error');
    } else {
        require_once($CFG->dirroot . '/mod/quiz/lib.php');
        require_once($CFG->dirroot . '/mod/quiz/locallib.php');
        $transaction = $DB->start_delegated_transaction();
        foreach ($selected as $cmid => $item) {
            $quiz = $item['quiz'];
            // An unchecked optional date selector returns 0, which means no
            // opening or closing restriction in Moodle quiz settings.
            $quiz->timeopen = $timeopen;
            $quiz->timeclose = $timeclose;
            $quiz->timemodified = time();
            $DB->update_record('quiz', (object)[
                'id' => $quiz->id,
                'timeopen' => $quiz->timeopen,
                'timeclose' => $quiz->timeclose,
                'timemodified' => $quiz->timemodified,
            ]);
            quiz_refresh_events($courseid, $quiz, $item['cm']);
            quiz_update_open_attempts(['quizid' => $quiz->id]);
            \core\event\course_module_updated::create_from_cm($item['cm'],
                context_module::instance($cmid))->trigger();
        }
        $transaction->allow_commit();
        rebuild_course_cache($courseid, true);
        redirect(
            new moodle_url('/course/view.php', [
                'id' => $courseid,
                'sectionid' => $sectionrecord->id,
            ]),
            get_string('updated', 'local_assignbulkclose', count($selected)),
            0,
            \core\output\notification::NOTIFY_SUCCESS
        );
    }
}

$mform->display();
echo $OUTPUT->footer();
