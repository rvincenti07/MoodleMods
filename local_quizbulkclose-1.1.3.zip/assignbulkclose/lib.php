<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

/**
 * Add the bulk closing dates tool to a course's settings navigation.
 *
 * @param settings_navigation $settingsnav
 * @param context $context
 */
function local_assignbulkclose_extend_settings_navigation(settings_navigation $settingsnav, context $context): void {
    if ($context->contextlevel !== CONTEXT_COURSE || !has_capability('moodle/course:manageactivities', $context)) {
        return;
    }

    $courseid = $context->instanceid;
    $url = new moodle_url('/local/assignbulkclose/index.php', ['courseid' => $courseid]);
    $settingsnav->add(
        get_string('pluginname', 'local_assignbulkclose'),
        $url,
        navigation_node::TYPE_SETTING,
        null,
        'local_assignbulkclose'
    );

    // The custom Bulk actions toolbar item uses this AMD handler to forward the
    // course page's selected activity IDs to the date form.
    global $PAGE;
    $PAGE->requires->js_call_amd('local_assignbulkclose/bulk_action', 'init', [
        $courseid,
        (new moodle_url('/local/assignbulkclose/index.php'))->out(false),
    ]);
}
