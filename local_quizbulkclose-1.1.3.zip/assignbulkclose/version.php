<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_assignbulkclose';
$plugin->version   = 2026101603;
$plugin->requires  = 2025100600; // Moodle 5.2.
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.1.3';
